CREATE TABLE [dbo].[tmp_sales] (

	[SaleID] varchar(8000) NULL, 
	[PropertyID] varchar(8000) NULL, 
	[ClientID] varchar(8000) NULL, 
	[BrokerID] varchar(8000) NULL, 
	[SaleDate] varchar(8000) NULL, 
	[SalePriceUSD] varchar(8000) NULL
);