CREATE TABLE [dbo].[tmp_properties] (

	[PropertyID] varchar(8000) NULL, 
	[ProjectID] varchar(8000) NULL, 
	[PropertyType] varchar(8000) NULL, 
	[Size_m2] varchar(8000) NULL, 
	[Bedrooms] varchar(8000) NULL, 
	[Bathrooms] varchar(8000) NULL, 
	[ListPriceUSD] varchar(8000) NULL, 
	[AvailabilityStatus] varchar(8000) NULL
);