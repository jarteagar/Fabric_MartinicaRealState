CREATE TABLE [dbo].[tmp_brokers] (

	[BrokerID] varchar(8000) NULL, 
	[BrokerName] varchar(8000) NULL, 
	[Region] varchar(8000) NULL, 
	[Email] varchar(8000) NULL
);