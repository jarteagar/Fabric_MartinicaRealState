CREATE TABLE [MRS].[leads] (

	[LeadID] varchar(8000) NULL, 
	[ClientID] varchar(8000) NULL, 
	[PropertyID] varchar(8000) NULL, 
	[CampaignID] varchar(8000) NULL, 
	[LeadDate] datetime2(6) NULL, 
	[LeadSource] varchar(8000) NULL
);