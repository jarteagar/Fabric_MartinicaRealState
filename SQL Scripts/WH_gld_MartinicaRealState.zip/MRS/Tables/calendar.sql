CREATE TABLE [MRS].[calendar] (

	[fecha] date NOT NULL, 
	[ann] int NULL, 
	[mes] int NULL, 
	[dia] int NULL, 
	[nombreMes] varchar(20) NULL, 
	[nombreDia] varchar(20) NULL, 
	[trimestre] int NULL, 
	[semanaAnn] int NULL
);