CREATE TABLE [MRS].[medidas] (

	[formula] varchar(4) NOT NULL
);