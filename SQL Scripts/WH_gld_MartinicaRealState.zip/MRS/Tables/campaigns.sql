CREATE TABLE [MRS].[campaigns] (

	[CampaignID] varchar(8000) NULL, 
	[Channel] varchar(8000) NULL, 
	[CampaignName] varchar(8000) NULL, 
	[StartDate] date NULL, 
	[EndDate] date NULL, 
	[BudgetUSD] real NULL
);