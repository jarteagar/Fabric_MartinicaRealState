CREATE TABLE [MRS].[sales] (

	[SaleID] varchar(8000) NULL, 
	[PropertyID] varchar(8000) NULL, 
	[ClientID] varchar(8000) NULL, 
	[BrokerID] varchar(8000) NULL, 
	[SaleDate] date NULL, 
	[SalePriceUSD] real NULL
);