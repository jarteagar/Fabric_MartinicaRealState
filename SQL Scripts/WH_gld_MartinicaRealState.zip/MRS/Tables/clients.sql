CREATE TABLE [MRS].[clients] (

	[ClientID] varchar(8000) NULL, 
	[FirstName] varchar(8000) NULL, 
	[LastName] varchar(8000) NULL, 
	[Email] varchar(8000) NULL, 
	[Region] varchar(8000) NULL
);